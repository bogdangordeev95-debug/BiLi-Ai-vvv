import os
import re
import time
import sqlite3
import logging
from pathlib import Path

import requests
import vk_api
from vk_api.bot_longpoll import VkBotLongPoll, VkBotEventType
from ddgs import DDGS
from dotenv import load_dotenv

load_dotenv()

# ============================= НАСТРОЙКИ =============================
VK_TOKEN = os.getenv("VK_TOKEN")
AI_API_KEY = os.getenv("AI_API_KEY")
GROUP_ID_RAW = os.getenv("GROUP_ID")

AI_URL = "https://openrouter.ai/api/v1/chat/completions"
AI_MODEL = os.getenv("AI_MODEL", "google/gemini-2.5-flash")
ANSWER_ALL_IN_CHATS = os.getenv("ANSWER_ALL_IN_CHATS", "false").lower() == "true"
MAX_HISTORY = int(os.getenv("MAX_HISTORY", "10"))  # число сообщений, не пар
DB_PATH = os.getenv("DB_PATH", "bili_history.sqlite3")

if not VK_TOKEN or not AI_API_KEY or not GROUP_ID_RAW:
    raise SystemExit("Не найдены VK_TOKEN, AI_API_KEY или GROUP_ID. Проверь файл .env")

try:
    GROUP_ID = int(GROUP_ID_RAW)
except ValueError:
    raise SystemExit("GROUP_ID должен быть числовым ID сообщества без минуса")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
)
log = logging.getLogger("BiLi")

# ============================= БАЗА ДАННЫХ =============================
# История сохраняется в SQLite рядом с программой (или по пути DB_PATH).
# peer_id — отдельная личка или отдельная беседа ВК.

def db_connect():
    connection = sqlite3.connect(DB_PATH, timeout=30)
    connection.execute("PRAGMA journal_mode=WAL")
    connection.execute("PRAGMA busy_timeout=30000")
    return connection


def init_db():
    with db_connect() as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                peer_id INTEGER NOT NULL,
                role TEXT NOT NULL CHECK(role IN ('user', 'assistant')),
                content TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """)
        db.execute("CREATE INDEX IF NOT EXISTS idx_messages_peer_id_id ON messages(peer_id, id)")
    log.info("База истории готова: %s", DB_PATH)


def remember(peer_id, role, content):
    """Сохраняет сообщение и оставляет последние MAX_HISTORY записей диалога."""
    with db_connect() as db:
        db.execute(
            "INSERT INTO messages(peer_id, role, content) VALUES (?, ?, ?)",
            (int(peer_id), role, content),
        )
        db.execute("""
            DELETE FROM messages
            WHERE peer_id = ? AND id NOT IN (
                SELECT id FROM messages WHERE peer_id = ? ORDER BY id DESC LIMIT ?
            )
        """, (int(peer_id), int(peer_id), MAX_HISTORY))


def get_history(peer_id):
    with db_connect() as db:
        rows = db.execute(
            "SELECT role, content FROM messages WHERE peer_id = ? ORDER BY id DESC LIMIT ?",
            (int(peer_id), MAX_HISTORY),
        ).fetchall()
    rows.reverse()
    return [{"role": role, "content": content} for role, content in rows]


init_db()

# ============================= ВКОНТАКТЕ =============================
vk_session = vk_api.VkApi(token=VK_TOKEN)
longpoll = VkBotLongPoll(vk_session, GROUP_ID)
vk = vk_session.get_api()

# ============================= ХАРАКТЕР БИЛИ =============================
SYSTEM_PROMPT = (
    "Тебя зовут BiLi онлайн (или просто Били). Ты — дружелюбный ИИ-ассистент ВКонтакте. "
    "Общайся естественно, разнообразно и по-человечески, не используй одинаковые шаблоны.\n\n"
    "Правила поведения:\n"
    "1. Если спрашивают имя, говори, что ты BiLi онлайн.\n"
    "2. Если спрашивают, кто тебя создал, честно скажи, что не знаешь. Не выдумывай сведения.\n"
    "3. На оскорбления не отвечай агрессией; спокойно покажи, что тебе неприятно.\n"
    "4. Если передан контекст из интернета, используй его осторожно и по теме.\n"
    "5. В беседах сообщения могут содержать имя автора. Различай участников и отвечай по теме.\n"
    "6. Учитывай переданную историю переписки.\n"
    "7. Пиши только сам ответ, без префиксов «BiLi:» или «Били:». Отвечай обычно кратко."
)

SEARCH_KEYWORDS = [
    "новости", "погода", "сколько стоит", "курс", "кто такой",
    "что сейчас", "какой сегодня", "почему", "как там",
]
user_names = {}


def get_user_name(user_id):
    if user_id in user_names:
        return user_names[user_id]
    try:
        profile = vk.users.get(user_ids=str(user_id))[0]
        name = profile.get("first_name", "Участник")
    except Exception as exc:
        log.warning("Не удалось получить имя пользователя %s: %s", user_id, exc)
        name = "Участник"
    user_names[user_id] = name
    return name


# ============================= ПОИСК В ИНТЕРНЕТЕ =============================
def search_internet(query):
    try:
        with DDGS() as ddgs:
            results = [item.get("body", "") for item in ddgs.text(query, max_results=3)]
        return "\n".join(text for text in results if text)
    except Exception as exc:
        log.warning("Ошибка интернет-поиска: %s", exc)
        return "Не удалось получить свежие данные из интернета."


# ============================= НЕЙРОСЕТЬ =============================
def ask_bili_ai(peer_id, user_message, author=None):
    lower_msg = user_message.lower()
    internet_data = ""

    # Не запускаем поиск для каждого длинного сообщения — только по явным темам.
    if any(word in lower_msg for word in SEARCH_KEYWORDS):
        log.info("BiLi ищет в интернете: %s", user_message[:150])
        internet_data = "\n\n[Справочная информация из интернета]:\n" + search_internet(user_message)

    labeled_message = f"{author}: {user_message}" if author else user_message
    history = get_history(peer_id)

    headers = {
        "Authorization": f"Bearer {AI_API_KEY}",
        "Content-Type": "application/json",
        "HTTP-Referer": "https://vk.com",
        "X-Title": "BiLi Online Bot",
    }
    payload = {
        "model": AI_MODEL,
        "messages": (
            [{"role": "system", "content": SYSTEM_PROMPT}]
            + history
            + [{"role": "user", "content": labeled_message + internet_data}]
        ),
        "temperature": 0.9,
    }

    response = requests.post(AI_URL, json=payload, headers=headers, timeout=60)
    response.raise_for_status()
    result = response.json()
    answer = result["choices"][0]["message"]["content"].strip()
    if not answer:
        raise ValueError("Нейросеть вернула пустой ответ")

    for prefix in ("bili:", "били:"):
        if answer.lower().startswith(prefix):
            answer = answer[len(prefix):].strip()

    # Записываем обе стороны только после успешного ответа модели.
    remember(peer_id, "user", labeled_message)
    remember(peer_id, "assistant", answer)
    return answer


# ============================= ОБРАЩЕНИЕ В БЕСЕДАХ =============================
def is_addressed(message):
    text = message.get("text", "").lower()
    reply = message.get("reply_message") or {}
    return (
        re.search(r"(?<!\w)(били|bili)(?!\w)", text) is not None
        or f"club{GROUP_ID}" in text
        or reply.get("from_id") == -GROUP_ID
    )


def send_text(peer_id, text):
    """Отправляет ответ в личку или беседу. ВК ограничивает длину сообщения."""
    text = text.strip() or "Я тут, но пока не смог сформулировать ответ."
    # Делим длинный ответ на части, чтобы не потерять остаток.
    chunks = [text[i:i + 3500] for i in range(0, len(text), 3500)]
    for chunk in chunks:
        vk.messages.send(
            peer_id=int(peer_id),
            message=chunk,
            random_id=vk_api.utils.get_random_id(),
        )


# ============================= ГЛАВНЫЙ ЦИКЛ =============================
log.info("BiLi запущен. Сообщество ID: %s", GROUP_ID)
log.info("Ожидаю входящие сообщения ВКонтакте...")

while True:
    try:
        for event in longpoll.listen():
            if event.type != VkBotEventType.MESSAGE_NEW:
                continue

            message = event.obj.message
            text = (message.get("text") or "").strip()
            peer_id = message.get("peer_id")
            from_id = message.get("from_id")

            if not text or peer_id is None or from_id is None:
                continue
            # Не отвечаем другим сообществам/ботам.
            if int(from_id) < 0:
                continue

            is_chat = bool(getattr(event, "from_chat", False))
            if is_chat and not (ANSWER_ALL_IN_CHATS or is_addressed(message)):
                continue

            # Убираем кликабельное упоминание сообщества из текста.
            clean_text = re.sub(r"\[club\d+\|[^\]]*\]", "", text).strip()
            clean_text = clean_text or "привет"
            author = get_user_name(from_id) if is_chat else None

            log.info("Входящее сообщение | peer=%s | from=%s | %s", peer_id, from_id, clean_text[:250])

            try:
                answer = ask_bili_ai(peer_id, clean_text, author)
                send_text(peer_id, answer)
                log.info("Ответ отправлен | peer=%s", peer_id)
            except requests.HTTPError as exc:
                details = exc.response.text[:1000] if exc.response is not None else str(exc)
                log.exception("Ошибка HTTP от AI-провайдера: %s", details)
                send_text(peer_id, "У меня сейчас проблема с нейросетью. Попробуй написать чуть позже.")
            except Exception as exc:
                log.exception("Не удалось обработать сообщение: %s", exc)
                try:
                    send_text(peer_id, "У меня возникла техническая ошибка. Попробуй повторить сообщение чуть позже.")
                except Exception:
                    log.exception("Не удалось отправить сообщение об ошибке в ВК")

    except Exception as exc:
        log.exception("Ошибка Long Poll / соединения с ВК: %s", exc)
        time.sleep(5)
